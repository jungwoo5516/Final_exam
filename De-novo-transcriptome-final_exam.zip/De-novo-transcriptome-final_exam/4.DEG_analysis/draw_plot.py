import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import argparse

def main():
    # 명령줄 인자 설정
    parser = argparse.ArgumentParser(description="Generate a scatter plot of TPM1 vs TPM2 with fold-change highlighting.")
    parser.add_argument("-1", "--file1", required=True, help="Path to the first input file.")
    parser.add_argument("-2", "--file2", required=True, help="Path to the second input file.")
    parser.add_argument("-out", "--output", required=True, help="Path to save the output PNG file.")
    parser.add_argument("-range", "--range", type=int, default=55000, help="Range for x and y axes (default: 55000).")
    args = parser.parse_args()

    # 파일 읽기
    file1 = pd.read_csv(args.file1, sep="\t")
    file2 = pd.read_csv(args.file2, sep="\t")

    # gene_id와 TPM 열만 추출
    data1 = file1[['gene_id', 'TPM']].copy()  # .copy() 추가
    data2 = file2[['gene_id', 'TPM']].copy()  # .copy() 추가

    # gene_id에서 ':' 이전 부분만 추출하여 새로운 열로 추가
    data1.loc[:, 'gene_id'] = data1['gene_id'].str.split(':').str[0]  # .loc 사용
    data2.loc[:, 'gene_id'] = data2['gene_id'].str.split(':').str[0]  # .loc 사용

    # gene_id를 기준으로 병합
    merged_data = pd.merge(data1, data2, on='gene_id', suffixes=('_file1', '_file2'))

    # Fold Change 계산 및 상태 결정
    merged_data['FoldChange'] = np.where(
        merged_data['TPM_file1'] > merged_data['TPM_file2'],
        merged_data['TPM_file1'] / merged_data['TPM_file2'],
        merged_data['TPM_file2'] / merged_data['TPM_file1']
    )

    merged_data['status'] = np.where(
        (merged_data['TPM_file1'] > merged_data['TPM_file2']) & (merged_data['FoldChange'] > 2),
        'blue',  # TPM1 > TPM2 and FoldChange > 2
        np.where(
            (merged_data['TPM_file2'] > merged_data['TPM_file1']) & (merged_data['FoldChange'] > 2),
            'red',  # TPM2 > TPM1 and FoldChange > 2
            'grey'  # Other cases
        )
    )

    # significant 열 추가
    merged_data['significant'] = np.where(
        merged_data['status'] == 'blue', 'sample1_dominant',
        np.where(merged_data['status'] == 'red', 'sample2_dominant', 'not_significant')
    )

    # merged_data를 TSV 파일로 저장
    tsv_output_path = f"{args.output}.tsv"
    merged_data.to_csv(tsv_output_path, sep="\t", index=False)
    print(f"Merged data saved as {tsv_output_path}")

    # Scatter Plot 생성
    plt.figure(figsize=(8, 8))
    for color in ['grey', 'red', 'blue']:
        subset = merged_data[merged_data['status'] == color]
        plt.scatter(
            subset['TPM_file1'],
            subset['TPM_file2'],
            c=color, alpha=0.7, edgecolor='k'
        )

    # y=x 기준선
    plt.plot([0, args.range], [0, args.range], color='black', linestyle='--')

    # 축 범위 설정
    plt.xlim(0, args.range)
    plt.ylim(0, args.range)

    plt.xlabel('TPM1')
    plt.ylabel('TPM2')

    # PNG 파일로 저장
    plt.savefig(args.output, dpi=300)  # High resolution for publication-quality output
    plt.close()  # Plot을 닫아서 메모리 관리

    print(f"Scatter plot saved as {args.output}")

if __name__ == "__main__":
    main()
